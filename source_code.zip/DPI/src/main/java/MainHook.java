
import android.app.*;
import android.content.pm.*;
import android.os.*;
import top.canyie.pine.*;
import top.canyie.pine.callback.*;
import top.canyie.pine.Pine.*;
import android.content.res.*;
import android.util.*;
import android.content.*;
import android.net.*;
import android.database.*;
import android.widget.*;

public class MainHook extends MethodHook
{
	public static void hook(ClassLoader classLoader, ApplicationInfo appInfo, Context context) throws Throwable
	{
		Pine.hook(Activity.class.getDeclaredMethod("onCreate", Bundle.class), new MainHook());
	}

	@Override
	public void beforeCall(Pine.CallFrame frame) throws Throwable
	{
		Activity activity = (Activity) frame.thisObject;
		Cursor cursor = Pine.queryContent(activity, "nea.dpi/" + activity.getPackageName());
		cursor.moveToFirst();
		int dpi = cursor.getInt(0);
		//Toast.makeText(activity, String.valueOf(dpi), Toast.LENGTH_SHORT).show();
		if (dpi == - 1) return;
		updateDPI(activity, dpi);
	}

	public void updateDPI(Activity activity, int newDPI)
	{
		DisplayMetrics metrics = activity.getResources().getDisplayMetrics();
		metrics.densityDpi = newDPI;
		activity.getResources().getConfiguration().densityDpi = newDPI;
		activity.getResources().updateConfiguration(
			activity.getResources().getConfiguration(),
			activity.getResources().getDisplayMetrics());
	}
}
