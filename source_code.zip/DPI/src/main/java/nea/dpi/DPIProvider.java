package nea.dpi;
import android.content.*;
import android.net.*;
import android.database.*;

public class DPIProvider extends ContentProvider
{

	@Override
	public boolean onCreate()
	{
		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] p2, String p3, String[] p4, String p5)
	{
		String packageName = uri.getPath().substring(1);
		int dpi  = DPIApplication.dpiSettings.getInt(packageName, - 1);
		MatrixCursor cursor = new MatrixCursor(new String[] {"dpi"});
		cursor.addRow(new Object[] {dpi});
		return cursor;
	}

	@Override
	public String getType(Uri p1)
	{
		return null;
	}

	@Override
	public Uri insert(Uri p1, ContentValues p2)
	{
		return null;
	}

	@Override
	public int delete(Uri p1, String p2, String[] p3)
	{
		return 0;
	}

	@Override
	public int update(Uri p1, ContentValues p2, String p3, String[] p4)
	{
		return 0;
	}
}
