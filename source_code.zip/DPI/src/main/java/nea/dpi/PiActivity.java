package nea.dpi;
import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
import android.content.pm.*;
import android.view.*;
import java.util.*;

public class PiActivity extends Activity
implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener
{
	
	ArrayAdapter<String> adapter;
	List<String> packageNames;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
		List<String> packageNames = this.packageNames = new ArrayList<>();
		SharedPreferences dpiSettings = DPIApplication.dpiSettings;
		PackageManager manager = getPackageManager();
		for (String packageName: dpiSettings.getAll().keySet())
		{
			try
			{
				ApplicationInfo info = manager.getApplicationInfo(packageName, 0);
				adapter.add(info.loadLabel(manager).toString());
				packageNames.add(packageName);
			}
			catch (PackageManager.NameNotFoundException e)
			{
			}
		}
		ListView list = new ListView(this);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		list.setOnItemLongClickListener(this);
		setContentView(list);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		final String packageName = packageNames.get(position);
		final EditText edit = new EditText(this);
		final SharedPreferences dpiSettings = DPIApplication.dpiSettings;
		edit.setText(String.valueOf(dpiSettings.getInt(packageName, getResources().getDisplayMetrics().densityDpi)));
		new AlertDialog.Builder(this).setTitle(adapter.getItem(position)).setView(edit).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					try
					{
						dpiSettings.edit().putInt(packageName, Integer.parseInt(edit.getText().toString())).commit();
					}
					catch (Exception e)
					{}
				}
			}).setNegativeButton(android.R.string.cancel, null).show();
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		DPIApplication.dpiSettings.edit().remove(packageNames.get(position)).commit();
		packageNames.remove(position);
		List<String> madapter = new ArrayList<>();
		for (int i = 0; i < adapter.getCount(); i ++)
		{
			if (i == position) continue;
			madapter.add(adapter.getItem(i));
		}
		adapter.clear();
		adapter.addAll(madapter.toArray(new String[madapter.size()]));
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add(R.string.add).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		PackageManager manager = getPackageManager();
		final ArrayAdapter<String> madapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
		final List<String> packages = new ArrayList<>();
		for (ApplicationInfo info: manager.getInstalledApplications(0))
		{
			madapter.add(info.loadLabel(manager).toString());
			packages.add(info.packageName);
		}
		new AlertDialog.Builder(this).setTitle(R.string.add).setAdapter(madapter, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int position)
				{
					String packageName = packages.get(position);
					if (packageNames.contains(packageName)) return;
					DPIApplication.dpiSettings.edit().putInt(packageName, getResources().getDisplayMetrics().densityDpi).commit();
					adapter.add(madapter.getItem(position));
					packageNames.add(packageName);
				}
			}).show();
		return true;
	}
}
