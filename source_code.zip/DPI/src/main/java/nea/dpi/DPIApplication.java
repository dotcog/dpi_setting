package nea.dpi;
import android.app.*;
import android.content.*;

public class DPIApplication extends Application
{

	public static SharedPreferences dpiSettings;

	@Override
	public void onCreate()
	{
		super.onCreate();
		dpiSettings = getSharedPreferences("dpi", MODE_PRIVATE);
	}
}
